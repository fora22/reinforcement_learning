```python
#!/usr/bin/env python
# coding: utf-8

# # Simple Reinforcement Learning with Tensorflow Part 4: Deep Q-Networks and Beyond
# 
# In this iPython notebook I implement a Deep Q-Network using both Double DQN and Dueling DQN. The agent learn to solve a navigation task in a basic grid world. To learn more, read here: https://medium.com/p/8438a3e2b8df
# 
# For more reinforcment learning tutorials, see:
# https://github.com/awjuliani/DeepRL-Agents

# In[1]:


from __future__ import division

import gym
import numpy as np
import random
import tensorflow as tf
import tensorflow.contrib.slim as slim
import matplotlib.pyplot as plt
import scipy.misc
import os
#get_ipython().run_line_magic('matplotlib', 'inline')


# ### Load the game environment

# Feel free to adjust the size of the gridworld. Making it smaller provides an easier task for our DQN agent, while making the world larger increases the challenge.

# In[2]:



```

    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:516: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint8 = np.dtype([("qint8", np.int8, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:517: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_quint8 = np.dtype([("quint8", np.uint8, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:518: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint16 = np.dtype([("qint16", np.int16, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:519: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_quint16 = np.dtype([("quint16", np.uint16, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:520: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint32 = np.dtype([("qint32", np.int32, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/framework/dtypes.py:525: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      np_resource = np.dtype([("resource", np.ubyte, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorboard/compat/tensorflow_stub/dtypes.py:541: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint8 = np.dtype([("qint8", np.int8, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorboard/compat/tensorflow_stub/dtypes.py:542: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_quint8 = np.dtype([("quint8", np.uint8, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorboard/compat/tensorflow_stub/dtypes.py:543: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint16 = np.dtype([("qint16", np.int16, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorboard/compat/tensorflow_stub/dtypes.py:544: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_quint16 = np.dtype([("quint16", np.uint16, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorboard/compat/tensorflow_stub/dtypes.py:545: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      _np_qint32 = np.dtype([("qint32", np.int32, 1)])
    /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorboard/compat/tensorflow_stub/dtypes.py:550: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      np_resource = np.dtype([("resource", np.ubyte, 1)])



```python
from gridworld import gameEnv

env = gameEnv(partial=False,size=8)
```


![png](output_1_0.png)



```python
class Qnetwork():
    def __init__(self,h_size):
        #The network recieves a frame from the game, flattened into an array.
        #It then resizes it and processes it through four convolutional layers.
        self.scalarInput =  tf.placeholder(shape=[None,21168],dtype=tf.float32)
        self.imageIn = tf.reshape(self.scalarInput,shape=[-1,84,84,3])
        self.conv1 = slim.conv2d( \
            inputs=self.imageIn,num_outputs=32,kernel_size=[8,8],stride=[4,4],padding='VALID', biases_initializer=None)
        self.conv2 = slim.conv2d( \
            inputs=self.conv1,num_outputs=64,kernel_size=[4,4],stride=[2,2],padding='VALID', biases_initializer=None)
        self.conv3 = slim.conv2d( \
            inputs=self.conv2,num_outputs=64,kernel_size=[3,3],stride=[1,1],padding='VALID', biases_initializer=None)
        self.conv4 = slim.conv2d( \
            inputs=self.conv3,num_outputs=h_size,kernel_size=[7,7],stride=[1,1],padding='VALID', biases_initializer=None)
        
        #We take the output from the final convolutional layer and split it into separate advantage and value streams.
        self.streamAC,self.streamVC = tf.split(self.conv4,2,3)
        self.streamA = slim.flatten(self.streamAC)
        self.streamV = slim.flatten(self.streamVC)
        xavier_init = tf.contrib.layers.xavier_initializer()
        self.AW = tf.Variable(xavier_init([h_size//2,env.actions]))
        self.VW = tf.Variable(xavier_init([h_size//2,1]))
        self.Advantage = tf.matmul(self.streamA,self.AW)
        self.Value = tf.matmul(self.streamV,self.VW)
        
        #Then combine them together to get our final Q-values.
        self.Qout = self.Value + tf.subtract(self.Advantage,tf.reduce_mean(self.Advantage,axis=1,keep_dims=True))
        self.predict = tf.argmax(self.Qout,1)
        
        #Below we obtain the loss by taking the sum of squares difference between the target and prediction Q values.
        self.targetQ = tf.placeholder(shape=[None],dtype=tf.float32)
        self.actions = tf.placeholder(shape=[None],dtype=tf.int32)
        self.actions_onehot = tf.one_hot(self.actions,env.actions,dtype=tf.float32)
        
        self.Q = tf.reduce_sum(tf.multiply(self.Qout, self.actions_onehot), axis=1)
        
        self.td_error = tf.square(self.targetQ - self.Q)
        self.loss = tf.reduce_mean(self.td_error)
        self.trainer = tf.train.AdamOptimizer(learning_rate=0.0001)
        self.updateModel = self.trainer.minimize(self.loss)
```


```python
class experience_buffer():
    def __init__(self, buffer_size = 50000):
        self.buffer = []
        self.buffer_size = buffer_size
    
    def add(self,experience):
        if len(self.buffer) + len(experience) >= self.buffer_size:
            self.buffer[0:(len(experience)+len(self.buffer))-self.buffer_size] = []
        self.buffer.extend(experience)
            
    def sample(self,size):
        return np.reshape(np.array(random.sample(self.buffer,size)),[size,5])
```


```python
def processState(states):
    return np.reshape(states,[21168])
```


```python
def updateTargetGraph(tfVars,tau):
    total_vars = len(tfVars)
    op_holder = []
    for idx,var in enumerate(tfVars[0:total_vars//2]):
        op_holder.append(tfVars[idx+total_vars//2].assign((var.value()*tau) + ((1-tau)*tfVars[idx+total_vars//2].value())))
    return op_holder

def updateTarget(op_holder,sess):
    for op in op_holder:
        sess.run(op)
```


```python
batch_size = 32 #How many experiences to use for each training step.
update_freq = 4 #How often to perform a training step.
y = .99 #Discount factor on the target Q-values
startE = 1 #Starting chance of random action
endE = 0.1 #Final chance of random action
annealing_steps = 10000. #How many steps of training to reduce startE to endE.
num_episodes = 10000 #How many episodes of game environment to train network with.
pre_train_steps = 10000 #How many steps of random actions before training begins.
max_epLength = 50 #The max allowed length of our episode.
load_model = False #Whether to load a saved model.
path = "./dqn" #The path to save our model to.
h_size = 512 #The size of the final convolutional layer before splitting it into Advantage and Value streams.
tau = 0.001 #Rate to update target network toward primary network
```


```python
tf.reset_default_graph()
mainQN = Qnetwork(h_size)
targetQN = Qnetwork(h_size)

init = tf.global_variables_initializer()

saver = tf.train.Saver()

trainables = tf.trainable_variables()

targetOps = updateTargetGraph(trainables,tau)

myBuffer = experience_buffer()

#Set the rate of random action decrease. 
e = startE
stepDrop = (startE - endE)/annealing_steps

#create lists to contain total rewards and steps per episode
jList = []
rList = []
total_steps = 0

#Make a path for our model to be saved in.
if not os.path.exists(path):
    os.makedirs(path)

with tf.Session() as sess:
    sess.run(init)
    if load_model == True:
        print('Loading Model...')
        ckpt = tf.train.get_checkpoint_state(path)
        saver.restore(sess,ckpt.model_checkpoint_path)
    for i in range(num_episodes):
        episodeBuffer = experience_buffer()
        #Reset environment and get first new observation
        s = env.reset()
        s = processState(s)
        d = False
        rAll = 0
        j = 0
        #The Q-Network
        while j < max_epLength: #If the agent takes longer than 200 moves to reach either of the blocks, end the trial.
            j+=1
            #Choose an action by greedily (with e chance of random action) from the Q-network
            if np.random.rand(1) < e or total_steps < pre_train_steps:
                a = np.random.randint(0,4)
            else:
                a = sess.run(mainQN.predict,feed_dict={mainQN.scalarInput:[s]})[0]
            s1,r,d = env.step(a)
            s1 = processState(s1)
            total_steps += 1
            episodeBuffer.add(np.reshape(np.array([s,a,r,s1,d]),[1,5])) #Save the experience to our episode buffer.
            
            if total_steps > pre_train_steps:
                if e > endE:
                    e -= stepDrop
                
                if total_steps % (update_freq) == 0:
                    trainBatch = myBuffer.sample(batch_size) #Get a random batch of experiences.
                    #Below we perform the Double-DQN update to the target Q-values
                    Q1 = sess.run(mainQN.predict,feed_dict={mainQN.scalarInput:np.vstack(trainBatch[:,3])})
                    Q2 = sess.run(targetQN.Qout,feed_dict={targetQN.scalarInput:np.vstack(trainBatch[:,3])})
                    end_multiplier = -(trainBatch[:,4] - 1)
                    doubleQ = Q2[range(batch_size),Q1]
                    targetQ = trainBatch[:,2] + (y*doubleQ * end_multiplier)
                    #Update the network with our target values.
                    _ = sess.run(mainQN.updateModel, \
                        feed_dict={mainQN.scalarInput:np.vstack(trainBatch[:,0]),mainQN.targetQ:targetQ, mainQN.actions:trainBatch[:,1]})
                    
                    updateTarget(targetOps,sess) #Update the target network toward the primary network.
            rAll += r
            s = s1
            
            if d == True:

                break
        
        myBuffer.add(episodeBuffer.buffer)
        jList.append(j)
        rList.append(rAll)
        #Periodically save the model. 
        if i % 1000 == 0:
            saver.save(sess,path+'/model-'+str(i)+'.ckpt')
            print("Saved Model")
        if len(rList) % 10 == 0:
            print(total_steps,np.mean(rList[-10:]), e)
    saver.save(sess,path+'/model-'+str(i)+'.ckpt')
print("Percent of succesful episodes: " + str(sum(rList)/num_episodes) + "%")
```

    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f41736897b8>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f41736897b8>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f41736897b8>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f41736897b8>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689d68>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689d68>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689d68>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689d68>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173689588>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:From /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/contrib/layers/python/layers/layers.py:1634: flatten (from tensorflow.python.layers.core) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use keras.layers.flatten instead.
    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4173689198>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172c6b710>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172c6b710>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172c6b710>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172c6b710>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173baf358>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173baf358>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173baf358>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4173baf358>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0940>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0940>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0940>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0940>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0b70>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0b70>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING: Entity <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0b70>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Conv.call of <tensorflow.python.layers.convolutional.Conv2D object at 0x7f4172bb0b70>>: AssertionError: Bad argument number for Name: 3, expecting 4
    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb0fd0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb0fd0>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb0fd0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb0fd0>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb06d8>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb06d8>>: AttributeError: module 'gast' has no attribute 'Num'
    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb06d8>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f4172bb06d8>>: AttributeError: module 'gast' has no attribute 'Num'
    Saved Model
    500 0.7 1
    1000 -0.7 1
    1500 1.5 1
    2000 1.1 1
    2500 0.4 1
    3000 -0.2 1
    3500 -0.5 1
    4000 1.3 1
    4500 1.2 1
    5000 2.2 1
    5500 1.2 1
    6000 0.4 1
    6500 0.3 1
    7000 1.6 1
    7500 0.6 1
    8000 1.3 1
    8500 1.4 1
    9000 0.2 1
    9500 -0.1 1
    10000 -0.1 1
    10500 0.3 0.9549999999999828
    11000 -0.1 0.9099999999999655
    11500 0.6 0.8649999999999483
    12000 0.9 0.819999999999931
    12500 1.3 0.7749999999999138
    13000 1.3 0.7299999999998965
    13500 0.7 0.6849999999998793
    14000 0.7 0.639999999999862
    14500 0.1 0.5949999999998448
    15000 0.9 0.5499999999998275
    15500 0.1 0.5049999999998103
    16000 0.2 0.4599999999998177
    16500 1.0 0.41499999999982823
    17000 0.9 0.36999999999983874
    17500 0.1 0.32499999999984924
    18000 1.1 0.27999999999985975
    18500 0.8 0.23499999999986562
    19000 1.1 0.18999999999986225
    19500 -0.1 0.14499999999985888
    20000 0.5 0.09999999999985551
    20500 0.0 0.09999999999985551
    21000 0.8 0.09999999999985551
    21500 -0.2 0.09999999999985551
    22000 0.8 0.09999999999985551
    22500 0.9 0.09999999999985551
    23000 0.9 0.09999999999985551
    23500 0.7 0.09999999999985551
    24000 0.9 0.09999999999985551
    24500 0.6 0.09999999999985551
    25000 0.3 0.09999999999985551
    25500 0.6 0.09999999999985551
    26000 0.3 0.09999999999985551
    26500 0.5 0.09999999999985551
    27000 0.2 0.09999999999985551
    27500 1.4 0.09999999999985551
    28000 1.0 0.09999999999985551
    28500 1.0 0.09999999999985551
    29000 0.8 0.09999999999985551
    29500 0.9 0.09999999999985551
    30000 1.2 0.09999999999985551
    30500 1.6 0.09999999999985551
    31000 0.4 0.09999999999985551
    31500 1.3 0.09999999999985551
    32000 1.3 0.09999999999985551
    32500 1.7 0.09999999999985551
    33000 0.9 0.09999999999985551
    33500 1.2 0.09999999999985551
    34000 1.1 0.09999999999985551
    34500 0.5 0.09999999999985551
    35000 0.5 0.09999999999985551
    35500 0.7 0.09999999999985551
    36000 0.6 0.09999999999985551
    36500 1.2 0.09999999999985551
    37000 0.6 0.09999999999985551
    37500 1.8 0.09999999999985551
    38000 1.3 0.09999999999985551
    38500 1.0 0.09999999999985551
    39000 0.7 0.09999999999985551
    39500 0.6 0.09999999999985551
    40000 0.7 0.09999999999985551
    40500 1.2 0.09999999999985551
    41000 1.4 0.09999999999985551
    41500 0.9 0.09999999999985551
    42000 1.7 0.09999999999985551
    42500 0.9 0.09999999999985551
    43000 1.0 0.09999999999985551
    43500 1.6 0.09999999999985551
    44000 1.2 0.09999999999985551
    44500 1.9 0.09999999999985551
    45000 1.3 0.09999999999985551
    45500 0.7 0.09999999999985551
    46000 2.0 0.09999999999985551
    46500 1.1 0.09999999999985551
    47000 1.8 0.09999999999985551
    47500 2.2 0.09999999999985551
    48000 1.7 0.09999999999985551
    48500 1.1 0.09999999999985551
    49000 1.6 0.09999999999985551
    49500 2.4 0.09999999999985551
    50000 1.7 0.09999999999985551
    Saved Model
    50500 1.4 0.09999999999985551
    51000 1.0 0.09999999999985551
    51500 2.7 0.09999999999985551
    52000 2.3 0.09999999999985551
    52500 1.3 0.09999999999985551
    53000 1.7 0.09999999999985551
    53500 1.8 0.09999999999985551
    54000 2.7 0.09999999999985551
    54500 2.5 0.09999999999985551
    55000 2.5 0.09999999999985551
    55500 2.8 0.09999999999985551
    56000 3.0 0.09999999999985551
    56500 2.7 0.09999999999985551
    57000 3.9 0.09999999999985551
    57500 1.7 0.09999999999985551
    58000 2.6 0.09999999999985551
    58500 2.9 0.09999999999985551
    59000 4.1 0.09999999999985551
    59500 2.6 0.09999999999985551
    60000 2.3 0.09999999999985551
    60500 2.9 0.09999999999985551
    61000 3.6 0.09999999999985551
    61500 4.5 0.09999999999985551
    62000 1.8 0.09999999999985551
    62500 4.0 0.09999999999985551
    63000 5.7 0.09999999999985551
    63500 4.9 0.09999999999985551
    64000 4.7 0.09999999999985551
    64500 3.4 0.09999999999985551
    65000 3.3 0.09999999999985551
    65500 3.2 0.09999999999985551
    66000 4.9 0.09999999999985551
    66500 3.8 0.09999999999985551
    67000 4.6 0.09999999999985551
    67500 5.0 0.09999999999985551
    68000 3.2 0.09999999999985551
    68500 6.0 0.09999999999985551
    69000 5.6 0.09999999999985551
    69500 4.4 0.09999999999985551
    70000 4.2 0.09999999999985551
    70500 6.1 0.09999999999985551
    71000 4.7 0.09999999999985551
    71500 6.6 0.09999999999985551
    72000 7.6 0.09999999999985551
    72500 9.8 0.09999999999985551
    73000 7.5 0.09999999999985551
    73500 5.6 0.09999999999985551
    74000 7.3 0.09999999999985551
    74500 6.5 0.09999999999985551
    75000 6.2 0.09999999999985551
    75500 5.6 0.09999999999985551
    76000 2.9 0.09999999999985551
    76500 8.9 0.09999999999985551
    77000 8.9 0.09999999999985551
    77500 10.0 0.09999999999985551
    78000 6.7 0.09999999999985551
    78500 9.3 0.09999999999985551
    79000 13.9 0.09999999999985551
    79500 7.9 0.09999999999985551
    80000 10.2 0.09999999999985551
    80500 7.5 0.09999999999985551
    81000 8.6 0.09999999999985551
    81500 12.1 0.09999999999985551
    82000 7.2 0.09999999999985551
    82500 13.6 0.09999999999985551
    83000 13.3 0.09999999999985551
    83500 8.2 0.09999999999985551
    84000 10.0 0.09999999999985551
    84500 8.2 0.09999999999985551
    85000 9.3 0.09999999999985551
    85500 8.3 0.09999999999985551
    86000 11.3 0.09999999999985551
    86500 11.0 0.09999999999985551
    87000 8.6 0.09999999999985551
    87500 11.1 0.09999999999985551
    88000 9.7 0.09999999999985551
    88500 10.0 0.09999999999985551
    89000 9.4 0.09999999999985551
    89500 11.5 0.09999999999985551
    90000 9.3 0.09999999999985551
    90500 10.9 0.09999999999985551
    91000 12.2 0.09999999999985551
    91500 8.7 0.09999999999985551
    92000 9.2 0.09999999999985551
    92500 6.2 0.09999999999985551
    93000 7.5 0.09999999999985551
    93500 9.6 0.09999999999985551
    94000 7.9 0.09999999999985551
    94500 9.1 0.09999999999985551
    95000 10.9 0.09999999999985551
    95500 11.2 0.09999999999985551
    96000 6.8 0.09999999999985551
    96500 8.4 0.09999999999985551
    97000 8.8 0.09999999999985551
    97500 10.9 0.09999999999985551
    98000 7.5 0.09999999999985551
    98500 11.6 0.09999999999985551
    99000 10.4 0.09999999999985551
    99500 9.0 0.09999999999985551
    100000 10.9 0.09999999999985551
    Saved Model
    100500 11.5 0.09999999999985551
    101000 11.7 0.09999999999985551
    101500 7.6 0.09999999999985551
    102000 8.1 0.09999999999985551
    102500 12.8 0.09999999999985551
    103000 8.3 0.09999999999985551
    103500 10.5 0.09999999999985551
    104000 8.3 0.09999999999985551
    104500 7.6 0.09999999999985551
    105000 13.0 0.09999999999985551
    105500 11.5 0.09999999999985551
    106000 10.2 0.09999999999985551
    106500 10.5 0.09999999999985551
    107000 11.3 0.09999999999985551
    107500 6.6 0.09999999999985551
    108000 9.2 0.09999999999985551
    108500 10.9 0.09999999999985551
    109000 11.0 0.09999999999985551
    109500 12.5 0.09999999999985551
    110000 10.7 0.09999999999985551
    110500 10.0 0.09999999999985551
    111000 9.9 0.09999999999985551
    111500 11.9 0.09999999999985551
    112000 10.6 0.09999999999985551
    112500 11.5 0.09999999999985551
    113000 12.2 0.09999999999985551
    113500 10.9 0.09999999999985551
    114000 11.7 0.09999999999985551
    114500 11.3 0.09999999999985551
    115000 9.4 0.09999999999985551
    115500 10.9 0.09999999999985551
    116000 12.9 0.09999999999985551
    116500 12.3 0.09999999999985551
    117000 11.3 0.09999999999985551
    117500 8.2 0.09999999999985551
    118000 10.5 0.09999999999985551
    118500 6.6 0.09999999999985551
    119000 8.6 0.09999999999985551
    119500 11.3 0.09999999999985551
    120000 11.9 0.09999999999985551
    120500 12.2 0.09999999999985551
    121000 12.0 0.09999999999985551
    121500 10.7 0.09999999999985551
    122000 11.7 0.09999999999985551
    122500 12.6 0.09999999999985551
    123000 11.5 0.09999999999985551
    123500 11.9 0.09999999999985551
    124000 10.1 0.09999999999985551
    124500 8.2 0.09999999999985551
    125000 8.8 0.09999999999985551
    125500 12.5 0.09999999999985551
    126000 12.8 0.09999999999985551
    126500 11.1 0.09999999999985551
    127000 12.1 0.09999999999985551
    127500 15.0 0.09999999999985551
    128000 9.0 0.09999999999985551
    128500 11.6 0.09999999999985551
    129000 10.0 0.09999999999985551
    129500 12.7 0.09999999999985551
    130000 13.4 0.09999999999985551
    130500 9.9 0.09999999999985551
    131000 7.8 0.09999999999985551
    131500 12.9 0.09999999999985551
    132000 10.2 0.09999999999985551
    132500 11.6 0.09999999999985551
    133000 10.2 0.09999999999985551
    133500 10.7 0.09999999999985551
    134000 13.2 0.09999999999985551
    134500 11.5 0.09999999999985551
    135000 10.5 0.09999999999985551
    135500 9.8 0.09999999999985551
    136000 12.1 0.09999999999985551
    136500 10.4 0.09999999999985551
    137000 16.8 0.09999999999985551
    137500 11.8 0.09999999999985551
    138000 8.3 0.09999999999985551
    138500 7.2 0.09999999999985551
    139000 9.9 0.09999999999985551
    139500 13.3 0.09999999999985551
    140000 13.0 0.09999999999985551
    140500 13.3 0.09999999999985551
    141000 9.9 0.09999999999985551
    141500 10.5 0.09999999999985551
    142000 7.5 0.09999999999985551
    142500 11.6 0.09999999999985551
    143000 10.9 0.09999999999985551
    143500 11.4 0.09999999999985551
    144000 7.9 0.09999999999985551
    144500 12.5 0.09999999999985551
    145000 12.0 0.09999999999985551
    145500 8.1 0.09999999999985551
    146000 10.4 0.09999999999985551
    146500 13.2 0.09999999999985551
    147000 12.6 0.09999999999985551
    147500 10.0 0.09999999999985551
    148000 10.9 0.09999999999985551
    148500 9.2 0.09999999999985551
    149000 15.5 0.09999999999985551
    149500 9.7 0.09999999999985551
    150000 12.3 0.09999999999985551
    Saved Model
    150500 13.7 0.09999999999985551
    151000 11.1 0.09999999999985551
    151500 12.0 0.09999999999985551
    152000 10.1 0.09999999999985551
    152500 12.5 0.09999999999985551
    153000 9.2 0.09999999999985551
    153500 11.8 0.09999999999985551
    154000 9.1 0.09999999999985551
    154500 12.3 0.09999999999985551
    155000 10.4 0.09999999999985551
    155500 14.6 0.09999999999985551
    156000 11.1 0.09999999999985551
    156500 7.5 0.09999999999985551
    157000 9.3 0.09999999999985551
    157500 12.5 0.09999999999985551
    158000 10.5 0.09999999999985551
    158500 10.3 0.09999999999985551
    159000 10.2 0.09999999999985551
    159500 10.4 0.09999999999985551
    160000 13.5 0.09999999999985551
    160500 10.8 0.09999999999985551
    161000 11.3 0.09999999999985551
    161500 8.7 0.09999999999985551
    162000 12.2 0.09999999999985551
    162500 9.4 0.09999999999985551
    163000 13.1 0.09999999999985551
    163500 11.2 0.09999999999985551
    164000 8.2 0.09999999999985551
    164500 8.1 0.09999999999985551
    165000 11.7 0.09999999999985551
    165500 9.2 0.09999999999985551
    166000 12.5 0.09999999999985551
    166500 9.7 0.09999999999985551
    167000 8.5 0.09999999999985551
    167500 9.1 0.09999999999985551
    168000 11.8 0.09999999999985551
    168500 12.7 0.09999999999985551
    169000 7.9 0.09999999999985551
    169500 10.7 0.09999999999985551
    170000 10.4 0.09999999999985551
    170500 7.7 0.09999999999985551
    171000 8.0 0.09999999999985551
    171500 11.9 0.09999999999985551
    172000 11.1 0.09999999999985551
    172500 14.7 0.09999999999985551
    173000 15.2 0.09999999999985551
    173500 12.4 0.09999999999985551
    174000 10.5 0.09999999999985551
    174500 5.7 0.09999999999985551
    175000 12.1 0.09999999999985551
    175500 8.9 0.09999999999985551
    176000 10.5 0.09999999999985551
    176500 11.2 0.09999999999985551
    177000 13.7 0.09999999999985551
    177500 11.7 0.09999999999985551
    178000 13.3 0.09999999999985551
    178500 12.3 0.09999999999985551
    179000 10.9 0.09999999999985551
    179500 8.9 0.09999999999985551
    180000 10.7 0.09999999999985551
    180500 12.4 0.09999999999985551
    181000 15.9 0.09999999999985551
    181500 9.6 0.09999999999985551
    182000 11.4 0.09999999999985551
    182500 13.3 0.09999999999985551
    183000 11.1 0.09999999999985551
    183500 6.2 0.09999999999985551
    184000 10.0 0.09999999999985551
    184500 9.3 0.09999999999985551
    185000 11.7 0.09999999999985551
    185500 9.2 0.09999999999985551
    186000 10.5 0.09999999999985551
    186500 10.9 0.09999999999985551
    187000 11.2 0.09999999999985551
    187500 15.8 0.09999999999985551
    188000 12.1 0.09999999999985551
    188500 9.1 0.09999999999985551
    189000 13.8 0.09999999999985551
    189500 10.3 0.09999999999985551
    190000 10.5 0.09999999999985551
    190500 9.5 0.09999999999985551
    191000 10.1 0.09999999999985551
    191500 10.9 0.09999999999985551
    192000 10.2 0.09999999999985551
    192500 10.1 0.09999999999985551
    193000 11.2 0.09999999999985551
    193500 16.5 0.09999999999985551
    194000 12.6 0.09999999999985551
    194500 13.4 0.09999999999985551
    195000 9.6 0.09999999999985551
    195500 10.3 0.09999999999985551
    196000 11.9 0.09999999999985551
    196500 12.3 0.09999999999985551
    197000 11.9 0.09999999999985551
    197500 9.0 0.09999999999985551
    198000 8.7 0.09999999999985551
    198500 12.0 0.09999999999985551
    199000 8.3 0.09999999999985551
    199500 11.0 0.09999999999985551
    200000 12.9 0.09999999999985551
    Saved Model
    200500 12.9 0.09999999999985551
    201000 13.8 0.09999999999985551
    201500 9.7 0.09999999999985551
    202000 9.6 0.09999999999985551
    202500 13.4 0.09999999999985551
    203000 9.0 0.09999999999985551
    203500 12.3 0.09999999999985551
    204000 8.7 0.09999999999985551
    204500 13.4 0.09999999999985551
    205000 11.3 0.09999999999985551
    205500 11.0 0.09999999999985551
    206000 11.7 0.09999999999985551
    206500 11.5 0.09999999999985551
    207000 9.0 0.09999999999985551
    207500 13.1 0.09999999999985551
    208000 9.9 0.09999999999985551
    208500 9.9 0.09999999999985551
    209000 12.1 0.09999999999985551
    209500 10.9 0.09999999999985551
    210000 7.3 0.09999999999985551
    210500 12.2 0.09999999999985551
    211000 11.8 0.09999999999985551
    211500 9.2 0.09999999999985551
    212000 9.3 0.09999999999985551
    212500 9.6 0.09999999999985551
    213000 14.2 0.09999999999985551
    213500 10.0 0.09999999999985551
    214000 13.6 0.09999999999985551
    214500 11.6 0.09999999999985551
    215000 12.5 0.09999999999985551
    215500 10.6 0.09999999999985551
    216000 12.5 0.09999999999985551
    216500 10.7 0.09999999999985551
    217000 13.6 0.09999999999985551
    217500 14.0 0.09999999999985551
    218000 9.1 0.09999999999985551
    218500 10.5 0.09999999999985551
    219000 11.2 0.09999999999985551
    219500 11.3 0.09999999999985551
    220000 15.2 0.09999999999985551
    220500 11.2 0.09999999999985551
    221000 12.3 0.09999999999985551
    221500 10.3 0.09999999999985551
    222000 8.9 0.09999999999985551
    222500 9.9 0.09999999999985551
    223000 11.3 0.09999999999985551
    223500 10.9 0.09999999999985551
    224000 11.5 0.09999999999985551
    224500 12.6 0.09999999999985551
    225000 8.2 0.09999999999985551
    225500 11.7 0.09999999999985551
    226000 11.6 0.09999999999985551
    226500 11.8 0.09999999999985551
    227000 7.5 0.09999999999985551
    227500 10.8 0.09999999999985551
    228000 11.6 0.09999999999985551
    228500 10.8 0.09999999999985551
    229000 8.3 0.09999999999985551
    229500 14.0 0.09999999999985551
    230000 8.9 0.09999999999985551
    230500 11.2 0.09999999999985551
    231000 12.0 0.09999999999985551
    231500 12.9 0.09999999999985551
    232000 11.0 0.09999999999985551
    232500 9.5 0.09999999999985551
    233000 10.3 0.09999999999985551
    233500 12.1 0.09999999999985551
    234000 8.3 0.09999999999985551
    234500 10.8 0.09999999999985551
    235000 10.4 0.09999999999985551
    235500 12.2 0.09999999999985551
    236000 13.5 0.09999999999985551
    236500 14.4 0.09999999999985551
    237000 11.8 0.09999999999985551
    237500 11.5 0.09999999999985551
    238000 11.5 0.09999999999985551
    238500 11.1 0.09999999999985551
    239000 11.2 0.09999999999985551
    239500 10.9 0.09999999999985551
    240000 10.7 0.09999999999985551
    240500 11.1 0.09999999999985551
    241000 14.6 0.09999999999985551
    241500 9.0 0.09999999999985551
    242000 12.6 0.09999999999985551
    242500 9.7 0.09999999999985551
    243000 10.0 0.09999999999985551
    243500 8.3 0.09999999999985551
    244000 12.4 0.09999999999985551
    244500 13.6 0.09999999999985551
    245000 12.6 0.09999999999985551
    245500 12.2 0.09999999999985551
    246000 8.1 0.09999999999985551
    246500 12.4 0.09999999999985551
    247000 9.2 0.09999999999985551
    247500 10.5 0.09999999999985551
    248000 12.9 0.09999999999985551
    248500 8.5 0.09999999999985551
    249000 11.2 0.09999999999985551
    249500 13.4 0.09999999999985551
    250000 12.3 0.09999999999985551
    WARNING:tensorflow:From /home/fora/anaconda3/envs/RL_test/lib/python3.6/site-packages/tensorflow/python/training/saver.py:960: remove_checkpoint (from tensorflow.python.training.checkpoint_management) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use standard file APIs to delete files with this prefix.
    Saved Model
    250500 12.2 0.09999999999985551
    251000 10.1 0.09999999999985551
    251500 10.9 0.09999999999985551
    252000 12.4 0.09999999999985551
    252500 12.0 0.09999999999985551
    253000 15.1 0.09999999999985551
    253500 13.0 0.09999999999985551
    254000 11.2 0.09999999999985551
    254500 10.6 0.09999999999985551
    255000 10.8 0.09999999999985551
    255500 14.6 0.09999999999985551
    256000 9.0 0.09999999999985551
    256500 13.0 0.09999999999985551
    257000 9.8 0.09999999999985551
    257500 9.2 0.09999999999985551
    258000 11.1 0.09999999999985551
    258500 12.2 0.09999999999985551
    259000 11.3 0.09999999999985551
    259500 10.7 0.09999999999985551
    260000 8.6 0.09999999999985551
    260500 11.2 0.09999999999985551
    261000 12.7 0.09999999999985551
    261500 10.0 0.09999999999985551
    262000 10.3 0.09999999999985551
    262500 8.3 0.09999999999985551
    263000 11.2 0.09999999999985551
    263500 10.8 0.09999999999985551
    264000 10.4 0.09999999999985551
    264500 13.3 0.09999999999985551
    265000 10.7 0.09999999999985551
    265500 12.9 0.09999999999985551
    266000 10.7 0.09999999999985551
    266500 12.5 0.09999999999985551
    267000 10.4 0.09999999999985551
    267500 12.8 0.09999999999985551
    268000 12.3 0.09999999999985551
    268500 11.6 0.09999999999985551
    269000 11.3 0.09999999999985551
    269500 10.5 0.09999999999985551
    270000 10.1 0.09999999999985551
    270500 12.6 0.09999999999985551
    271000 9.0 0.09999999999985551
    271500 12.4 0.09999999999985551
    272000 13.5 0.09999999999985551
    272500 14.8 0.09999999999985551
    273000 12.9 0.09999999999985551
    273500 9.4 0.09999999999985551
    274000 11.0 0.09999999999985551
    274500 10.2 0.09999999999985551
    275000 10.9 0.09999999999985551
    275500 11.0 0.09999999999985551
    276000 11.4 0.09999999999985551
    276500 10.8 0.09999999999985551
    277000 12.3 0.09999999999985551
    277500 14.9 0.09999999999985551
    278000 8.6 0.09999999999985551
    278500 10.0 0.09999999999985551
    279000 15.3 0.09999999999985551
    279500 9.9 0.09999999999985551
    280000 12.4 0.09999999999985551
    280500 12.7 0.09999999999985551
    281000 14.8 0.09999999999985551
    281500 11.2 0.09999999999985551
    282000 10.7 0.09999999999985551
    282500 13.8 0.09999999999985551
    283000 10.1 0.09999999999985551
    283500 14.0 0.09999999999985551
    284000 13.4 0.09999999999985551
    284500 9.8 0.09999999999985551
    285000 10.0 0.09999999999985551
    285500 8.5 0.09999999999985551
    286000 10.7 0.09999999999985551
    286500 8.8 0.09999999999985551
    287000 12.6 0.09999999999985551
    287500 12.4 0.09999999999985551
    288000 13.2 0.09999999999985551
    288500 9.2 0.09999999999985551
    289000 13.3 0.09999999999985551
    289500 8.3 0.09999999999985551
    290000 16.8 0.09999999999985551
    290500 12.7 0.09999999999985551
    291000 10.2 0.09999999999985551
    291500 12.9 0.09999999999985551
    292000 13.9 0.09999999999985551
    292500 11.9 0.09999999999985551
    293000 11.2 0.09999999999985551
    293500 12.1 0.09999999999985551
    294000 13.5 0.09999999999985551
    294500 12.0 0.09999999999985551
    295000 13.5 0.09999999999985551
    295500 11.5 0.09999999999985551
    296000 11.9 0.09999999999985551
    296500 11.6 0.09999999999985551
    297000 11.1 0.09999999999985551
    297500 11.9 0.09999999999985551
    298000 12.7 0.09999999999985551
    298500 13.6 0.09999999999985551
    299000 9.6 0.09999999999985551
    299500 10.4 0.09999999999985551
    300000 12.4 0.09999999999985551
    Saved Model
    300500 13.4 0.09999999999985551
    301000 12.2 0.09999999999985551
    301500 9.9 0.09999999999985551
    302000 14.0 0.09999999999985551
    302500 10.3 0.09999999999985551
    303000 12.5 0.09999999999985551
    303500 10.3 0.09999999999985551
    304000 9.7 0.09999999999985551
    304500 14.3 0.09999999999985551
    305000 11.3 0.09999999999985551
    305500 9.8 0.09999999999985551
    306000 7.6 0.09999999999985551
    306500 9.0 0.09999999999985551
    307000 7.8 0.09999999999985551
    307500 13.6 0.09999999999985551
    308000 10.7 0.09999999999985551
    308500 10.7 0.09999999999985551
    309000 14.2 0.09999999999985551
    309500 14.9 0.09999999999985551
    310000 12.1 0.09999999999985551
    310500 15.5 0.09999999999985551
    311000 13.5 0.09999999999985551
    311500 11.7 0.09999999999985551
    312000 12.2 0.09999999999985551
    312500 10.3 0.09999999999985551
    313000 10.7 0.09999999999985551
    313500 13.4 0.09999999999985551
    314000 14.2 0.09999999999985551
    314500 12.2 0.09999999999985551
    315000 10.9 0.09999999999985551
    315500 14.8 0.09999999999985551
    316000 9.5 0.09999999999985551
    316500 10.7 0.09999999999985551
    317000 13.7 0.09999999999985551
    317500 10.0 0.09999999999985551
    318000 12.3 0.09999999999985551
    318500 12.2 0.09999999999985551
    319000 14.4 0.09999999999985551
    319500 12.3 0.09999999999985551
    320000 10.8 0.09999999999985551
    320500 12.7 0.09999999999985551
    321000 10.8 0.09999999999985551
    321500 13.6 0.09999999999985551
    322000 12.8 0.09999999999985551
    322500 12.8 0.09999999999985551
    323000 12.8 0.09999999999985551
    323500 12.3 0.09999999999985551
    324000 12.4 0.09999999999985551
    324500 11.4 0.09999999999985551
    325000 9.7 0.09999999999985551
    325500 11.1 0.09999999999985551
    326000 12.1 0.09999999999985551
    326500 12.4 0.09999999999985551
    327000 13.5 0.09999999999985551
    327500 10.9 0.09999999999985551
    328000 11.2 0.09999999999985551
    328500 10.7 0.09999999999985551
    329000 14.1 0.09999999999985551
    329500 14.7 0.09999999999985551
    330000 10.3 0.09999999999985551
    330500 14.0 0.09999999999985551
    331000 13.2 0.09999999999985551
    331500 15.8 0.09999999999985551
    332000 12.9 0.09999999999985551
    332500 11.0 0.09999999999985551
    333000 8.4 0.09999999999985551
    333500 7.2 0.09999999999985551
    334000 11.2 0.09999999999985551
    334500 13.6 0.09999999999985551
    335000 9.6 0.09999999999985551
    335500 14.8 0.09999999999985551
    336000 15.1 0.09999999999985551
    336500 11.9 0.09999999999985551
    337000 11.3 0.09999999999985551
    337500 12.6 0.09999999999985551
    338000 12.0 0.09999999999985551
    338500 12.3 0.09999999999985551
    339000 10.8 0.09999999999985551
    339500 9.8 0.09999999999985551
    340000 10.1 0.09999999999985551
    340500 12.6 0.09999999999985551
    341000 9.3 0.09999999999985551
    341500 15.2 0.09999999999985551
    342000 11.5 0.09999999999985551
    342500 12.6 0.09999999999985551
    343000 11.8 0.09999999999985551
    343500 10.5 0.09999999999985551
    344000 11.8 0.09999999999985551
    344500 13.2 0.09999999999985551
    345000 14.9 0.09999999999985551
    345500 13.1 0.09999999999985551
    346000 15.0 0.09999999999985551
    346500 11.2 0.09999999999985551
    347000 9.7 0.09999999999985551
    347500 12.2 0.09999999999985551
    348000 12.0 0.09999999999985551
    348500 14.6 0.09999999999985551
    349000 13.4 0.09999999999985551
    349500 10.6 0.09999999999985551
    350000 11.4 0.09999999999985551
    Saved Model
    350500 9.8 0.09999999999985551
    351000 12.4 0.09999999999985551
    351500 10.9 0.09999999999985551
    352000 11.1 0.09999999999985551
    352500 11.4 0.09999999999985551
    353000 8.4 0.09999999999985551
    353500 11.9 0.09999999999985551
    354000 8.1 0.09999999999985551
    354500 12.0 0.09999999999985551
    355000 9.9 0.09999999999985551
    355500 12.0 0.09999999999985551
    356000 9.6 0.09999999999985551
    356500 15.4 0.09999999999985551
    357000 11.7 0.09999999999985551
    357500 13.4 0.09999999999985551
    358000 12.6 0.09999999999985551
    358500 10.0 0.09999999999985551
    359000 14.0 0.09999999999985551
    359500 8.5 0.09999999999985551
    360000 12.5 0.09999999999985551
    360500 12.4 0.09999999999985551
    361000 15.5 0.09999999999985551
    361500 11.9 0.09999999999985551
    362000 10.6 0.09999999999985551
    362500 11.9 0.09999999999985551
    363000 9.1 0.09999999999985551
    363500 12.4 0.09999999999985551
    364000 12.8 0.09999999999985551
    364500 14.0 0.09999999999985551
    365000 12.1 0.09999999999985551
    365500 12.4 0.09999999999985551
    366000 12.1 0.09999999999985551
    366500 13.2 0.09999999999985551
    367000 11.7 0.09999999999985551
    367500 15.0 0.09999999999985551
    368000 11.3 0.09999999999985551
    368500 11.6 0.09999999999985551
    369000 11.4 0.09999999999985551
    369500 11.2 0.09999999999985551
    370000 13.1 0.09999999999985551
    370500 11.3 0.09999999999985551
    371000 13.8 0.09999999999985551
    371500 11.9 0.09999999999985551
    372000 9.2 0.09999999999985551
    372500 14.9 0.09999999999985551
    373000 11.4 0.09999999999985551
    373500 12.4 0.09999999999985551
    374000 12.4 0.09999999999985551
    374500 12.4 0.09999999999985551
    375000 16.2 0.09999999999985551
    375500 9.7 0.09999999999985551
    376000 11.8 0.09999999999985551
    376500 10.8 0.09999999999985551
    377000 8.6 0.09999999999985551
    377500 13.7 0.09999999999985551
    378000 11.6 0.09999999999985551
    378500 16.9 0.09999999999985551
    379000 11.9 0.09999999999985551
    379500 11.1 0.09999999999985551
    380000 12.6 0.09999999999985551
    380500 10.2 0.09999999999985551
    381000 16.6 0.09999999999985551
    381500 13.4 0.09999999999985551
    382000 12.0 0.09999999999985551
    382500 13.1 0.09999999999985551
    383000 12.5 0.09999999999985551
    383500 12.0 0.09999999999985551
    384000 8.7 0.09999999999985551
    384500 9.1 0.09999999999985551
    385000 10.6 0.09999999999985551
    385500 13.0 0.09999999999985551
    386000 13.0 0.09999999999985551
    386500 11.8 0.09999999999985551
    387000 12.7 0.09999999999985551
    387500 9.3 0.09999999999985551
    388000 10.6 0.09999999999985551
    388500 10.7 0.09999999999985551
    389000 13.9 0.09999999999985551
    389500 10.4 0.09999999999985551
    390000 14.8 0.09999999999985551
    390500 12.3 0.09999999999985551
    391000 11.8 0.09999999999985551
    391500 12.3 0.09999999999985551
    392000 13.8 0.09999999999985551
    392500 13.7 0.09999999999985551
    393000 12.2 0.09999999999985551
    393500 14.0 0.09999999999985551
    394000 10.6 0.09999999999985551
    394500 9.0 0.09999999999985551
    395000 7.9 0.09999999999985551
    395500 12.8 0.09999999999985551
    396000 12.0 0.09999999999985551
    396500 9.6 0.09999999999985551
    397000 11.0 0.09999999999985551
    397500 13.6 0.09999999999985551
    398000 12.8 0.09999999999985551
    398500 12.5 0.09999999999985551
    399000 12.9 0.09999999999985551
    399500 14.0 0.09999999999985551
    400000 13.1 0.09999999999985551
    Saved Model
    400500 12.8 0.09999999999985551
    401000 12.1 0.09999999999985551
    401500 12.0 0.09999999999985551
    402000 12.4 0.09999999999985551
    402500 13.7 0.09999999999985551
    403000 12.9 0.09999999999985551
    403500 14.3 0.09999999999985551
    404000 8.2 0.09999999999985551
    404500 11.0 0.09999999999985551
    405000 11.8 0.09999999999985551
    405500 14.3 0.09999999999985551
    406000 14.2 0.09999999999985551
    406500 11.0 0.09999999999985551
    407000 11.7 0.09999999999985551
    407500 13.9 0.09999999999985551
    408000 14.0 0.09999999999985551
    408500 11.4 0.09999999999985551
    409000 9.3 0.09999999999985551
    409500 10.8 0.09999999999985551
    410000 12.0 0.09999999999985551
    410500 13.0 0.09999999999985551
    411000 14.2 0.09999999999985551
    411500 11.2 0.09999999999985551
    412000 12.7 0.09999999999985551
    412500 13.1 0.09999999999985551
    413000 13.6 0.09999999999985551
    413500 10.6 0.09999999999985551
    414000 8.9 0.09999999999985551
    414500 11.7 0.09999999999985551
    415000 11.5 0.09999999999985551
    415500 11.3 0.09999999999985551
    416000 11.4 0.09999999999985551
    416500 14.3 0.09999999999985551
    417000 13.1 0.09999999999985551
    417500 15.4 0.09999999999985551
    418000 14.6 0.09999999999985551
    418500 11.2 0.09999999999985551
    419000 10.0 0.09999999999985551
    419500 8.9 0.09999999999985551
    420000 12.4 0.09999999999985551
    420500 10.9 0.09999999999985551
    421000 11.8 0.09999999999985551
    421500 13.5 0.09999999999985551
    422000 13.4 0.09999999999985551
    422500 11.9 0.09999999999985551
    423000 13.9 0.09999999999985551
    423500 12.3 0.09999999999985551
    424000 10.4 0.09999999999985551
    424500 15.2 0.09999999999985551
    425000 10.7 0.09999999999985551
    425500 9.3 0.09999999999985551
    426000 10.5 0.09999999999985551
    426500 13.7 0.09999999999985551
    427000 14.4 0.09999999999985551
    427500 13.4 0.09999999999985551
    428000 13.3 0.09999999999985551
    428500 12.4 0.09999999999985551
    429000 13.1 0.09999999999985551
    429500 7.8 0.09999999999985551
    430000 11.0 0.09999999999985551
    430500 11.2 0.09999999999985551
    431000 12.5 0.09999999999985551
    431500 10.0 0.09999999999985551
    432000 11.9 0.09999999999985551
    432500 15.3 0.09999999999985551
    433000 9.4 0.09999999999985551
    433500 13.0 0.09999999999985551
    434000 12.4 0.09999999999985551
    434500 10.6 0.09999999999985551
    435000 10.9 0.09999999999985551
    435500 13.9 0.09999999999985551
    436000 12.3 0.09999999999985551
    436500 13.8 0.09999999999985551
    437000 10.4 0.09999999999985551
    437500 12.3 0.09999999999985551
    438000 14.5 0.09999999999985551
    438500 11.6 0.09999999999985551
    439000 12.3 0.09999999999985551
    439500 10.5 0.09999999999985551
    440000 12.9 0.09999999999985551
    440500 8.5 0.09999999999985551
    441000 14.3 0.09999999999985551
    441500 13.3 0.09999999999985551
    442000 9.5 0.09999999999985551
    442500 13.6 0.09999999999985551
    443000 12.8 0.09999999999985551
    443500 9.0 0.09999999999985551
    444000 12.9 0.09999999999985551
    444500 12.4 0.09999999999985551
    445000 7.3 0.09999999999985551
    445500 12.9 0.09999999999985551
    446000 16.2 0.09999999999985551
    446500 12.2 0.09999999999985551
    447000 13.2 0.09999999999985551
    447500 13.4 0.09999999999985551
    448000 12.0 0.09999999999985551
    448500 12.0 0.09999999999985551
    449000 11.0 0.09999999999985551
    449500 12.6 0.09999999999985551
    450000 12.3 0.09999999999985551
    Saved Model
    450500 11.6 0.09999999999985551
    451000 12.6 0.09999999999985551
    451500 12.9 0.09999999999985551
    452000 15.7 0.09999999999985551
    452500 11.9 0.09999999999985551
    453000 12.1 0.09999999999985551
    453500 12.3 0.09999999999985551
    454000 15.0 0.09999999999985551
    454500 10.7 0.09999999999985551
    455000 12.3 0.09999999999985551
    455500 12.0 0.09999999999985551
    456000 12.8 0.09999999999985551
    456500 10.3 0.09999999999985551
    457000 11.1 0.09999999999985551
    457500 11.3 0.09999999999985551
    458000 12.4 0.09999999999985551
    458500 13.7 0.09999999999985551
    459000 13.2 0.09999999999985551
    459500 13.2 0.09999999999985551
    460000 10.8 0.09999999999985551
    460500 12.2 0.09999999999985551
    461000 9.0 0.09999999999985551
    461500 9.9 0.09999999999985551
    462000 12.8 0.09999999999985551
    462500 12.6 0.09999999999985551
    463000 13.2 0.09999999999985551
    463500 13.2 0.09999999999985551
    464000 13.3 0.09999999999985551
    464500 11.4 0.09999999999985551
    465000 11.2 0.09999999999985551
    465500 12.6 0.09999999999985551
    466000 12.3 0.09999999999985551
    466500 9.9 0.09999999999985551
    467000 10.5 0.09999999999985551
    467500 15.5 0.09999999999985551
    468000 11.3 0.09999999999985551
    468500 14.2 0.09999999999985551
    469000 7.4 0.09999999999985551
    469500 11.3 0.09999999999985551
    470000 11.5 0.09999999999985551
    470500 10.1 0.09999999999985551
    471000 13.4 0.09999999999985551
    471500 10.4 0.09999999999985551
    472000 13.5 0.09999999999985551
    472500 12.8 0.09999999999985551
    473000 11.1 0.09999999999985551
    473500 10.0 0.09999999999985551
    474000 11.8 0.09999999999985551
    474500 13.3 0.09999999999985551
    475000 12.0 0.09999999999985551
    475500 14.8 0.09999999999985551
    476000 12.2 0.09999999999985551
    476500 16.2 0.09999999999985551
    477000 9.0 0.09999999999985551
    477500 11.9 0.09999999999985551
    478000 12.6 0.09999999999985551
    478500 10.3 0.09999999999985551
    479000 13.8 0.09999999999985551
    479500 13.0 0.09999999999985551
    480000 13.9 0.09999999999985551
    480500 9.2 0.09999999999985551
    481000 12.3 0.09999999999985551
    481500 11.8 0.09999999999985551
    482000 12.1 0.09999999999985551
    482500 11.5 0.09999999999985551
    483000 11.9 0.09999999999985551
    483500 13.5 0.09999999999985551
    484000 11.9 0.09999999999985551
    484500 12.4 0.09999999999985551
    485000 8.6 0.09999999999985551
    485500 13.0 0.09999999999985551
    486000 11.1 0.09999999999985551
    486500 12.4 0.09999999999985551
    487000 13.9 0.09999999999985551
    487500 12.3 0.09999999999985551
    488000 11.3 0.09999999999985551
    488500 12.6 0.09999999999985551
    489000 11.7 0.09999999999985551
    489500 11.6 0.09999999999985551
    490000 12.7 0.09999999999985551
    490500 8.0 0.09999999999985551
    491000 10.4 0.09999999999985551
    491500 11.5 0.09999999999985551
    492000 12.9 0.09999999999985551
    492500 16.0 0.09999999999985551
    493000 14.7 0.09999999999985551
    493500 13.2 0.09999999999985551
    494000 13.7 0.09999999999985551
    494500 11.4 0.09999999999985551
    495000 15.2 0.09999999999985551
    495500 11.0 0.09999999999985551
    496000 11.3 0.09999999999985551
    496500 13.5 0.09999999999985551
    497000 12.1 0.09999999999985551
    497500 14.6 0.09999999999985551
    498000 11.9 0.09999999999985551
    498500 9.8 0.09999999999985551
    499000 12.3 0.09999999999985551
    499500 13.7 0.09999999999985551
    500000 13.2 0.09999999999985551
    Percent of succesful episodes: 10.0506%



```python
rMat = np.resize(np.array(rList),[len(rList)//100,100])
rMean = np.average(rMat,1)
plt.plot(rMean)
```




    [<matplotlib.lines.Line2D at 0x7f4173b1dcc0>]




![png](output_8_1.png)



```python

```
